package com.example.tarefas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TarefasApplication {
    public static void main(String[] args){
        SpringApplication.run(TarefasApplication.class, args);
        System.out.println("api rodando");
        System.out.println("📋 Swagger UI: http://localhost:8080/swagger-ui.html");
        System.out.println("🗄️ H2 Console: http://localhost:8080/h2-console");
    }
}